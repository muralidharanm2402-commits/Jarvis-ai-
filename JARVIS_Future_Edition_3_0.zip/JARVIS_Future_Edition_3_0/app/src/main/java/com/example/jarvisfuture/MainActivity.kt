package com.example.jarvisfuture

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Navy = Color(0xFF071426)
private val Panel = Color(0xFF10243B)
private val Cyan = Color(0xFF42D9F5)
private val Muted = Color(0xFF9DB8CC)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var speech: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("en", "IN")
        }
        setContent { JarvisApp(
            onSpeak = { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply") },
            onListen = { onResult ->
                if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                    onResult("Speech recognition is not available on this device.")
                } else {
                    speech?.destroy()
                    speech = SpeechRecognizer.createSpeechRecognizer(this)
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
                    }
                    speech?.setRecognitionListener(object : RecognitionListener {
                        override fun onResults(results: Bundle?) {
                            onResult(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty())
                        }
                        override fun onError(error: Int) { onResult("I couldn't hear that. Please try again.") }
                        override fun onReadyForSpeech(params: Bundle?) {}
                        override fun onBeginningOfSpeech() {}
                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}
                        override fun onEndOfSpeech() {}
                        override fun onPartialResults(partialResults: Bundle?) {}
                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                    speech?.startListening(intent)
                }
            }
        ) }
    }

    override fun onDestroy() {
        speech?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun JarvisApp(onSpeak: (String) -> Unit, onListen: ((String) -> Unit) -> Unit) {
    var input by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf(
        "JARVIS" to "Good evening. JARVIS systems are online. How may I assist you?"
    ) }
    val context = LocalContext.current
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            listening = true
            onListen { result ->
                listening = false
                if (result.isNotBlank()) {
                    input = result
                }
            }
        }
    }

    fun send(text: String) {
        if (text.isBlank()) return
        messages.add("YOU" to text)
        val answer = demoReply(text)
        messages.add("JARVIS" to answer)
        input = ""
        onSpeak(answer)
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, background = Navy, surface = Panel, onPrimary = Navy,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF06101E), Navy, Color(0xFF0B2540))))
                .padding(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("J.A.R.V.I.S", color = Cyan, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("FUTURE EDITION 3.0  •  DEMO MODE", color = Muted, fontSize = 10.sp)
                }
                Text("● ONLINE", color = Color(0xFF5CE6A8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(18.dp))
            Box(
                Modifier.fillMaxWidth().height(145.dp)
                    .background(Brush.radialGradient(listOf(Color(0xFF164D6A), Color(0xFF0C2037), Navy)), RoundedCornerShape(22.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("◉", color = Cyan, fontSize = 68.sp)
                    Text(if (listening) "LISTENING…" else "SYSTEM READY", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModuleCard("AI CORE", "Demo replies", Modifier.weight(1f))
                ModuleCard("VOICE", "Speech + TTS", Modifier.weight(1f))
                ModuleCard("VISION", "Coming soon", Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
            Text("ASSISTANT CHANNEL", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(messages) { (sender, body) ->
                    Column(
                        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(12.dp)
                    ) {
                        Text(sender, color = if (sender == "JARVIS") Cyan else Color(0xFFFFC66D), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(body, color = Color.White, fontSize = 14.sp)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f).background(Color(0xFF132B43), RoundedCornerShape(14.dp)).padding(14.dp)) {
                    BasicTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
                        decorationBox = { inner ->
                            if (input.isEmpty()) Text("Ask JARVIS…", color = Muted, fontSize = 14.sp)
                            inner()
                        }
                    )
                }
                Button(onClick = {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        listening = true
                        onListen { result -> listening = false; if (result.isNotBlank()) input = result }
                    } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }, colors = ButtonDefaults.buttonColors(containerColor = Panel), contentPadding = PaddingValues(13.dp)) {
                    Text("🎙")
                }
                Button(onClick = { send(input) }, contentPadding = PaddingValues(horizontal = 16.dp, vertical = 13.dp)) {
                    Text("SEND")
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("Demo only • Connect a secure backend for real AI", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun ModuleCard(title: String, subtitle: String, modifier: Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(12.dp)).padding(10.dp)) {
        Text(title, color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 9.sp)
    }
}

private fun demoReply(text: String): String {
    val q = text.lowercase()
    return when {
        "hello" in q || "hi" in q || "வணக்கம்" in q -> "Hello! I am JARVIS. Your demo assistant is ready."
        "time" in q -> "I can show device time after the real Android system integration is added."
        "location" in q -> "Location sharing must be enabled by the person sharing it. This demo does not track anyone."
        "weather" in q -> "Weather needs a live weather service connection. This is currently demo mode."
        "who are you" in q -> "I am JARVIS Future Edition 3.0, an assistant interface prototype."
        else -> "I understood: \"$text\". This is a demo response. Connect a secure AI backend to enable intelligent answers."
    }
}
